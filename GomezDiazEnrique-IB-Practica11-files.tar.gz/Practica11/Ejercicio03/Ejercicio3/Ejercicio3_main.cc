#include "Ejercicio3.h"

int main(int argc, char *argv[]){
    Usage(argc, argv);
    std::ifstream file(argv[1]);
    if(!file.is_open()){
        std::cout << "No se pudo abrir el archivo: " << argv[1] << std::endl;
        exit(EXIT_SUCCESS);
    }



  std::vector<std::ofstream> Outfiles(26);
  std::string palabra;
  while(file >> palabra){
    if(!Outfiles[std::toupper(palabra[0]) - 'A'].is_open()){
      Outfiles[std::toupper(palabra[0]) - 'A'].open(GenerarArchivos(palabra));
    }
      Outfiles[std::toupper(palabra[0]) - 'A'] << palabra << " ";
   }

  file.close();
  return 0;
}