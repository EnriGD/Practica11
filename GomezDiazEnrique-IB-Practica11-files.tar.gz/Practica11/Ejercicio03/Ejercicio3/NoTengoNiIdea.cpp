#include <iostream>
#include <fstream>
#include <vector>
#include <cctype>

// Función para obtener el nombre del archivo de salida correspondiente a una letra
std::string GetOutputFileName(char letter) {
    return std::string(1, std::toupper(letter)) + ".txt";
}

int main(int argc, char* argv[]) {
    // Verificar si se proporciona un argumento de línea de comandos
    if (argc != 2) {
        std::cerr << "Uso: " << argv[0] << " archivo_entrada" << std::endl;
        return 1;
    }

    // Abrir el archivo de entrada
    std::ifstream inputFile(argv[1]);
    if (!inputFile.is_open()) {
        std::cerr << "No se pudo abrir el archivo de entrada: " << argv[1] << std::endl;
        return 1;
    }

    // Vector de archivos de salida, uno por cada letra del alfabeto
    std::vector<std::ofstream> outputFiles(26);

    // Leer palabras del archivo de entrada y escribirlas en los archivos de salida correspondientes
    std::string word;
    while (inputFile >> word) {
        if (!word.empty()) {  // Ignorar palabras vacías
            char firstLetter = std::toupper(word[0]);
            if (std::isalpha(firstLetter)) {
                // Asegurarse de que haya un archivo de salida para la letra actual
                if (!outputFiles[firstLetter - 'A'].is_open()) {
                    outputFiles[firstLetter - 'A'].open(GetOutputFileName(firstLetter));
                }

                // Escribir la palabra en el archivo de salida correspondiente
                outputFiles[firstLetter - 'A'] << word << "\n";
            }
        }
    }

    // Cerrar todos los archivos de salida
    for (auto& file : outputFiles) {
        file.close();
    }

    // Cerrar el archivo de entrada
    inputFile.close();

    return 0;
}