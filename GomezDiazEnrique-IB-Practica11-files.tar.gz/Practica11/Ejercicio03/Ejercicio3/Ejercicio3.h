#include <iostream>
#include <fstream>
#include <vector>

void Usage(int argc, char *argv[]);
std::string GenerarArchivos(const std::string& palabra);