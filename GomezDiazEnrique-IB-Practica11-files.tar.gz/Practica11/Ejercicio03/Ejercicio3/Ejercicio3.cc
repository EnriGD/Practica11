#include "Ejercicio3.h"

void Usage(int argc, char *argv[]){
    if(argc != 2){
        std::cout << "File " << argv[0] << ": Faltan parametros " << std::endl;
        exit(EXIT_SUCCESS);
    }

}

std::string GenerarArchivos(const std::string& palabra){
    return std::string(1, std::toupper(palabra[0])) + ".txt";
}

