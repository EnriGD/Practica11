#include "Ejercicio2.h"

void Usage(int argc, char *argv[]){
if (argc < 3) {
        std::cerr << "Uso: " << argv[0] << " <nombre_del_archivo>" << std::endl;
        exit(EXIT_SUCCESS);
    }
}

std::string CambiarVocales(const std::string& palabra){
    std::string resultado = palabra;
    for (int i = 0; i < palabra.size(); i++){
        if(palabra[i] == 'a'){
            resultado[i] = 'e';
        }else{
            if(palabra[i] == 'e'){
                resultado[i] = 'i';
            }else{
                if(palabra[i] == 'i'){
                    resultado[i] = 'o';
                }else{
                    if(palabra[i] == 'o'){
                        resultado[i] = 'u';
                    }else{
                        if(palabra[i] == 'u'){
                        resultado[i] = 'a';
                        }
                    }
                }
            }
        }
        
    }

    return resultado;
}