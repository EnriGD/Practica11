#include <iostream>
#include <string>
#include <fstream>

void Usage(int arc, char* argv[]);

std::string CambiarVocales(const std::string& palabra);