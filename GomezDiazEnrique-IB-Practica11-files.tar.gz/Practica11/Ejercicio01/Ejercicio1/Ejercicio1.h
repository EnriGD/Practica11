#include <iostream>
#include <istream>
#include <ostream>
#include <vector>
#pragma once

int ContadorVocales(const std::string& palabra);
int ContadorConsonantes(const std::string& palabra);