#include <iostream>
#include <fstream>
#include <string>

void Encriptar(std::string& mensaje, const int numeroCrypto);
void Desencriptar(std::string& mensaje, const int numeroCrypto);

