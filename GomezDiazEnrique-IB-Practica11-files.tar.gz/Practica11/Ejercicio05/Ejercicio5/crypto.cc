#include "crypto.h"

void Encriptar(std::string& mensaje, const int numeroCrypto){
    for(int i = 0; i < mensaje.size(); i++){
        mensaje[i] = char((mensaje[i] + numeroCrypto) % 255);
    }
}

void Desencriptar(std::string& mensaje, const int numeroCrypto){
    for(int i = 0; i < mensaje.size(); i++){
    if((mensaje[i] - numeroCrypto) < 0){
        mensaje[i] = char(((-1)*(mensaje[i] - numeroCrypto)) % 255);
    }
    mensaje[i] = char(mensaje[i] - numeroCrypto);
    }
}